import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { ShipmentStatisticsComponent } from "../shipment-statistics/shipment-statistics.component";
import { MyDailyTasksComponent } from "../my-daily-tasks/my-daily-tasks.component";
import { AnalysisComponent } from "../analysis/analysis.component";
import { BlogListingComponent } from "../blog-listing/blog-listing.component";

import { Chart } from "chart.js";
import { SidebarService } from "../sidebar.service";// Service to detect sidebar state


@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [AnalysisComponent, MyDailyTasksComponent, ShipmentStatisticsComponent, BlogListingComponent],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  @ViewChild('shipmentChart') shipmentChartRef!: ElementRef<HTMLCanvasElement>;
  shipmentChart!: Chart;

  constructor(private sidebarService: SidebarService) { }

  ngOnInit() {
    this.sidebarService.sidebarState$.subscribe(() => {
      this.triggerChartResize(); // Resize chart when sidebar toggles
    });
  }

  triggerChartResize() {
    setTimeout(() => {
      const event = new Event('resize');
      window.dispatchEvent(event); // Forces Chart.js to resize
    }, 300); // Small delay to allow layout updates first
  }

  handleViewAll(event: string) {
    console.log('${event} clicked');
  }
}
