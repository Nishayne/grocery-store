import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyDailyTasksComponent } from './my-daily-tasks.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('MyDailyTasksComponent', () => {
  let component: MyDailyTasksComponent;
  let fixture: ComponentFixture<MyDailyTasksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MyDailyTasksComponent, HttpClientTestingModule]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyDailyTasksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
