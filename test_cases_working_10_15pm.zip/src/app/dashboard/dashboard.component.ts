import { Component } from "@angular/core";
import { ShipmentStatisticsComponent } from "../shipment-statistics/shipment-statistics.component";
import { MyDailyTasksComponent } from "../my-daily-tasks/my-daily-tasks.component";
import { AnalysisComponent } from "../analysis/analysis.component";


@Component({
    selector:'app-dashboard',
    standalone:true,
    imports:[AnalysisComponent, MyDailyTasksComponent,  ShipmentStatisticsComponent],
    templateUrl: './dashboard.component.html',
    styleUrls:['./dashboard.component.scss']
})
export class DashboardComponent{
    handleViewAll(event:string){
    console.log('${event} clicked');
    }
}