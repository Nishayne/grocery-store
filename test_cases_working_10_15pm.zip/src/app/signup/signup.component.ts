import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NgIf } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-sign-up',
  standalone: true,
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
  imports: [NgIf, ReactiveFormsModule]
})
export class SignUpComponent {
  signUpForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.signUpForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validator: this.passwordMatchValidator });
  }

  passwordMatchValidator(group: FormGroup) {
    return group.get('password')?.value === group.get('confirmPassword')?.value
      ? null : { mismatch: true };
  }

  onSubmit() {
    if (this.signUpForm.valid) {
      const username = this.signUpForm.value.username;

      // Check if the username already exists
      this.http.get<any[]>('http://localhost:3000/users?username=' + username).subscribe(users => {
        if (users.length > 0) {
          alert('Username already exists!');
        } else {
          this.registerUser();
        }
      });
    }
  }

  registerUser() {
    const user = {
      username: this.signUpForm.value.username,
      password: this.signUpForm.value.password
    };

    this.http.post('http://localhost:3000/users', user).subscribe(() => {
      alert('User registered successfully');
      this.signUpForm.reset();
    });
  }
}
