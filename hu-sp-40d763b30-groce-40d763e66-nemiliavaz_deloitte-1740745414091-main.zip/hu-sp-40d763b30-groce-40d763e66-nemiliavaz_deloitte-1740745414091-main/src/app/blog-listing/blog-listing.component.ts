import { Component, OnInit } from '@angular/core';
import { BlogService } from '../blog.service';
import { NgFor } from '@angular/common';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-blog-listing',
  standalone: true,
  imports:[NgFor,DatePipe],
  templateUrl: './blog-listing.component.html',
  styleUrl: './blog-listing.component.scss'
})
export class BlogListingComponent implements OnInit {
  blogs: any[] = [];
  filteredBlogs: any[] = [];
  years: number[] = [];
  selectedYear: number = new Date().getFullYear();

  constructor(private blogService: BlogService) {}

  ngOnInit(): void {
    this.blogService.getBlogs().subscribe(data => {
      this.blogs = data;
      this.filteredBlogs = [...this.blogs];
      this.getUniqueYears();
    });
  }

  getUniqueYears(): void {
    this.years = [...new Set(this.blogs.map(blog =>
      new Date(blog.publishedDate).getFullYear()))];
    this.years.sort((a, b) => b - a);
  }

  filterByYear(year: number): void {
    this.selectedYear = year;
    this.filteredBlogs = this.blogs.filter(blog =>
      new Date(blog.publishedDate).getFullYear() === year);
  }
}
