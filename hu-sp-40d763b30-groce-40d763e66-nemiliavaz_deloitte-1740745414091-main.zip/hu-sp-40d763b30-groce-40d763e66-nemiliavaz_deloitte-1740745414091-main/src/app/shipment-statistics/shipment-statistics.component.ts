import { Component, OnInit, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Chart, ChartData, ChartOptions } from 'chart.js/auto';

@Component({
  selector: 'app-shipment-statistics',
  standalone: true,
  templateUrl: './shipment-statistics.component.html',
  styleUrls: ['./shipment-statistics.component.scss']
})
export class ShipmentStatisticsComponent implements OnInit {
  @ViewChild('pieChart') pieChart!: ElementRef<HTMLCanvasElement>;
  apiUrl = 'http://localhost:3000/shipmentsList';
  shipmentData: any[] = [];
  chart!: Chart;

  @Output() viewAll=new EventEmitter<string>();
   
  emitViewAll(){
    this.viewAll.emit('Shipment Statistics');
  }

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchShipmentStatistics();
  }

  fetchShipmentStatistics() {
    this.http.get<any[]>(this.apiUrl).subscribe({
      next: (data) => {
        this.shipmentData = data;
        this.createChart();
      },
      error: (err) => console.error('Failed to fetch shipment statistics', err)
    });
  }

  createChart() {
    const completed = this.shipmentData.filter(s => s.status === 'completed').length;
    const inTransit = this.shipmentData.filter(s => s.status === 'in-transit').length;
    const failed = this.shipmentData.filter(s => s.status === 'failed').length;
    const pending = this.shipmentData.filter(s => s.status === 'pending').length;

    const chartData: ChartData<'doughnut'> = {
      labels: ['Completed', 'In-Transit', 'Failed', 'Pending'],
      datasets: [
        {
          data: [completed, inTransit, failed, pending],
          backgroundColor: ['#4CAF50', '#FFC107', '#F44336', '#FFEB3B'],
          hoverOffset: 4
        }
      ]
    };

    const chartOptions: ChartOptions<'doughnut'> = {
      responsive: true,
      plugins: {
        tooltip: {
          callbacks: {
            label: function (tooltipItem) {
              const value = tooltipItem.raw as number;
              const total = completed + inTransit + failed + pending;
              const percentage = ((value / total) * 100).toFixed(2);
              return `${tooltipItem.label}: ${value} (${percentage}%)`;
            }
          }
        }
      }
    };

    this.chart = new Chart(this.pieChart.nativeElement, {
      type: 'doughnut',
      data: chartData,
      options: chartOptions
    });
  }
}