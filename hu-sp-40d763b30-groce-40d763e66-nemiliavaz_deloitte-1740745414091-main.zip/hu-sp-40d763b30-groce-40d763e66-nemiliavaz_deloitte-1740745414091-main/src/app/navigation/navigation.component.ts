import { Component } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-navigation',
  standalone: true,
  imports:[NgFor,NgIf, RouterModule],
  templateUrl: './navigation.component.html',
  styleUrl: './navigation.component.scss',
})
export class NavigationComponent {
  menuItems = [
    { icon: 'dashboard', label: 'Dashboard', route:'/dashboard' },
    { icon: 'inventory', label: 'Stocks Management', route:'/stock' },
    { icon: 'local_shipping', label: 'Shipment Tracking', route:'/ship' },
    { icon: 'bar_chart', label: 'Reports & Analytics',route:'/bar' },
    { icon: 'groups', label: 'Customer Management', route:'/group' },
    { icon: 'article', label: 'Food Safety Blogs', route:'/blogs' },
    { icon: 'settings', label: 'Settings', route:'/settings' },
    { icon: 'person', label: 'My Account', route:'/account' },
    { icon: 'help', label: 'Help & Support', route:'/help' }
  ];
  isExpanded = false;

  toggleMenu(expand: boolean) {
    this.isExpanded = expand;
  }
}