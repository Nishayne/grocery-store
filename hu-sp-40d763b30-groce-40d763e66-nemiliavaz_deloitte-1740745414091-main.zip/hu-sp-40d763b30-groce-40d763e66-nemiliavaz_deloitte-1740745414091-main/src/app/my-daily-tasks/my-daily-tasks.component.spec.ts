import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyDailyTasksComponent } from './my-daily-tasks.component';

describe('MyDailyTasksComponent', () => {
  let component: MyDailyTasksComponent;
  let fixture: ComponentFixture<MyDailyTasksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MyDailyTasksComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MyDailyTasksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
