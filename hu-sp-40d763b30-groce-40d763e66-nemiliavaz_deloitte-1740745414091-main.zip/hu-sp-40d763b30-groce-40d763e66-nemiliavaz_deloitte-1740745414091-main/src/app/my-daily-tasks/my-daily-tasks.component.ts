import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgClass, NgFor } from '@angular/common';

@Component({
  selector: 'app-my-daily-tasks',
  standalone: true,
  templateUrl: './my-daily-tasks.component.html',
  imports:[NgClass,NgFor],
  styleUrls: ['./my-daily-tasks.component.scss']
})
export class MyDailyTasksComponent implements OnInit {
  Object=Object;
  shipmentData: any = [];
  totalTasks: number = 0;
  taskSummary: any = {
    CashManagement: 0,
    FinancialReporting: 0,
    VendorsContracts: 0,
    Advertising: 0,
  };

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchShipments();
  }

  fetchShipments() {
    this.http.get('http://localhost:3000/shipmentsList').subscribe((data: any) => {
      this.shipmentData = data;
      this.calculateTaskSummary();
    });
  }

  calculateTaskSummary() {
    this.shipmentData.forEach((shipment: any) => {
      this.taskSummary[shipment.task.replace(' ', '')]++;
      this.totalTasks++;
    });
  }

  formatTask(task: string):string{
    return task.replace(/([A-Z])/g, ' $1').trim();
  }
}