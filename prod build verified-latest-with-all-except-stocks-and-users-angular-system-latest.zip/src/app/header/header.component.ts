import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { SearchService } from '../search.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [MatIconModule, CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  hideSearch = false;
  constructor(private router: Router, private searchService: SearchService) {
    // Subscribe to route changes
    this.router.events.subscribe(() => {
      this.hideSearch = this.router.url.includes('dashboard');
    });
  }

  onSearch(event: Event) {
    const input = event.target as HTMLInputElement;
    this.searchService.updateSearchText(input.value);
  }

}
