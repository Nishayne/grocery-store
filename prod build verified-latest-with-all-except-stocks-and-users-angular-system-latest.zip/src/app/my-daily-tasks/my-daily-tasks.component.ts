import { AfterViewInit, Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgClass, NgFor } from '@angular/common';
import { Chart, ChartOptions, ChartData, ArcElement } from 'chart.js/auto';

Chart.register(ArcElement);

@Component({
  selector: 'app-my-daily-tasks',
  standalone: true,
  templateUrl: './my-daily-tasks.component.html',
  imports: [NgClass, NgFor],
  styleUrls: ['./my-daily-tasks.component.scss']
})
export class MyDailyTasksComponent implements OnInit, AfterViewInit {
  Object = Object;
  shipmentData: any = [];
  totalTasks: number = 0;
  taskSummary: any = {
    CashManagement: 0,
    FinancialReporting: 0,
    VendorsContracts: 0,
    Advertising: 0,
  };

  ngAfterViewInit() {
    this.createDonutChart();
  }

  createDonutChart() {
    const ctx = document.getElementById('dailyTasksChart') as HTMLCanvasElement;

    if (!ctx) return;

    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Completed', 'In-Progress', 'Pending', 'Failed'],
        datasets: [
          {
            data: [60, 26, 9, 5], // Example percentages
            backgroundColor: ['#5E60CE', '#48CAE4', '#FFB703', '#FB5607'],
            hoverOffset: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'right' // Or any other valid position
          },
          tooltip: {
            enabled: true, // Show tooltips on hover
          },
        },
      },
    });
  }

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.fetchShipments();
  }

  fetchShipments() {
    this.http.get('http://localhost:3000/shipmentsList').subscribe((data: any) => {
      this.shipmentData = data;
      this.calculateTaskSummary();
    });
  }

  calculateTaskSummary() {
    this.shipmentData.forEach((shipment: any) => {
      this.taskSummary[shipment.task.replace(' ', '')]++;
      this.totalTasks++;
    });
  }

  formatTask(task: string): string {
    return task.replace(/([A-Z])/g, ' $1').trim();
  }
}
