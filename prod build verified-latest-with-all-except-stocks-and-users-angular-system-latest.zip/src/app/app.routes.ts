import { RouterModule, Routes } from '@angular/router';
import { provideRouter } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './signup/signup.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ShipmentTrackingComponent } from './shipment-tracking/shipment-tracking.component';
import { BlogListingComponent } from './blog-listing/blog-listing.component';
import { NgModel } from '@angular/forms';
import { Component, NgModule } from '@angular/core';
import { LayoutComponent } from './layout/layout.component';

export const routes: Routes = [] = [
    {path:'', component: LoginComponent},
    {path:'signup', component: SignUpComponent},
    {
        path:'',
        component:LayoutComponent,
        children:[
            {path:'dashboard',component:DashboardComponent},
            // {path:'stock',component:StocksManagementComponent},
            {path:'ship',component:ShipmentTrackingComponent},
            {path:'blogs',component:BlogListingComponent}
        ]
    }
];
export const AppRoutes=provideRouter(routes);