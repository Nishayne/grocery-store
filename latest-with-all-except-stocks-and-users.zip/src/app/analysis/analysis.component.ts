import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ChartComponent, ApexAxisChartSeries, ApexChart, ApexXAxis, ApexTitleSubtitle } from 'ngx-apexcharts';

@Component({
  selector: 'app-analysis',
  standalone: true,
  templateUrl: './analysis.component.html',
  styleUrls: ['./analysis.component.scss'],
  imports: [ChartComponent]
})
export class AnalysisComponent implements OnInit {
  apiUrl = 'http://localhost:3000/stockInventoryAnalysisChartData';

  series: ApexAxisChartSeries = [];
  chart: ApexChart = {
    type: 'bar',
    height: 350
  };
  xaxis: ApexXAxis = {
    categories: []
  };
  title: ApexTitleSubtitle = {
    text: 'Stock Inventory Analysis'
  };

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchChartData();
  }

  fetchChartData(): void {
    this.http.get<any[]>(this.apiUrl).subscribe((data) => {
      this.xaxis.categories = data.map(item => new Date(item.date).toLocaleString('en-US', { month: 'short' }));
      const activeOrders = data.map(item => item.numOfActiveOrders);
      const inactiveOrders = data.map(item => item.numOfInactiveOrders);

      this.series = [
        {
          name: 'Active Orders',
          data: activeOrders
        },
        {
          name: 'Inactive Orders',
          data: inactiveOrders
        }
      ];
    });
  }
}