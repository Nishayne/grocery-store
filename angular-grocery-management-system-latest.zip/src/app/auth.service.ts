import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(@Inject(PLATFORM_ID) private platformId: any) { }

  private TOKEN_KEY = 'jwt_token';

  isAuthenticated(): boolean {
    const token = this.getToken();
    return !!token; // Returns true if token exists
  }

  getToken(): string | null {
    return (isPlatformBrowser(this.platformId)) ? localStorage.getItem(this.TOKEN_KEY) : null;
  }

  login(token: string) {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem(this.TOKEN_KEY, token);
    }
  }

  logout() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem(this.TOKEN_KEY);
    }
  }
}
