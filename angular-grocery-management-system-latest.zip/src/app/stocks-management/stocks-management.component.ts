import { AfterViewInit, Component, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, OnInit, ViewChild, ElementRef } from '@angular/core';
import { StockService } from '../stock.service';
import { MatColumnDef, MatHeaderRowDef, MatRowDef, MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { SearchService } from '../search.service';

import { Chart, ChartConfiguration } from 'chart.js';

@Component({
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  selector: 'app-stocks-management',
  templateUrl: './stocks-management.component.html',
  styleUrls: ['./stocks-management.component.scss'],
  standalone: true,
  imports: [MatTableModule, MatPaginatorModule, MatSortModule, MatHeaderRowDef, MatRowDef,MatColumnDef,]
})
export class StocksManagementComponent implements OnInit, AfterViewInit {
  @ViewChild('stockChart') stockChartRef!: ElementRef;
  //stockInventoryList: any[] = [];
  dataSource = new MatTableDataSource<any>();
  displayedColumns: string[]= ['id', 'product', 'quantity', 'status'];

  constructor(private stockService: StockService, private searchService: SearchService) {}
  @ViewChild(MatSort) sort!: MatSort;  // Get MatSort reference

  ngAfterViewInit() {
    this.createStockChart();
    this.dataSource.sort = this.sort;  // Attach sorting
  }

  createStockChart() {
    new Chart(this.stockChartRef.nativeElement, {
      type: 'bar',
      data: {
        labels: this.dataSource.data.map(item => item.product),
        datasets: [{
          label: 'Stock Quantity',
          data: this.dataSource.data.map(item => item.quantity),
          backgroundColor: ['red', 'orange', 'green']
        }]
      },
      options: {
        responsive: true
      }
    } as ChartConfiguration);
  }

  ngOnInit(): void {
    this.fetchStockInventory();
    this.searchService.searchText$.subscribe((searchText) => {
      this.dataSource.filter = searchText.trim().toLowerCase();
    });
  }

  fetchStockInventory(): void {
    this.stockService.getStockInventory().subscribe(data => {
      //this.stockInventoryList = data;
      this.dataSource.data = data;
    });
  }
}
