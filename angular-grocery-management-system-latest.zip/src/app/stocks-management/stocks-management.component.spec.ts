import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StocksManagementComponent } from './stocks-management.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { StockService } from '../stock.service';

describe('StocksManagementComponent', () => {
  let component: StocksManagementComponent;
  let fixture: ComponentFixture<StocksManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, StocksManagementComponent, BrowserAnimationsModule],
      declarations: [],//StocksManagementComponent is standalone and cannot be declared but it needs to be imported
      providers: [StockService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StocksManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
