import { AfterViewInit, Component, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { NgClass } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatTableDataSource } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { DatePipe } from '@angular/common';
import { SearchService } from '../search.service';
import { MatSort, MatSortModule } from '@angular/material/sort';
//import L from 'leaflet';

@Component({
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  standalone: true,
  imports: [MatTableModule,MatPaginatorModule,NgClass,MatIconModule,MatButtonModule, DatePipe, CommonModule, MatSortModule],
  templateUrl: './shipment-tracking.component.html',
  styleUrls: ['./shipment-tracking.component.scss']
})
export class ShipmentTrackingComponent implements OnInit, AfterViewInit {
  private map!: any; // lazy loading L.Map;
  displayedColumns: string[] = ['consumer', 'product', 'supplier', 'date', 'quantity', 'price', 'cashier', 'status', 'action'];
  dataSource = new MatTableDataSource<any>();
  locations: any[] = [];

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private http: HttpClient, private searchService: SearchService) {}
  @ViewChild(MatSort) sort!: MatSort;  // Get MatSort reference

  ngAfterViewInit() {
    this.initializeMap();
    this.dataSource.sort = this.sort;  // Attach sorting
  }

  private async initializeMap(): Promise<void> {

    const L = await import('leaflet');

    // Fix marker icon paths
    const iconUrl = 'assets/leaflet/marker-icon.png';
    const iconRetinaUrl = 'assets/leaflet/marker-icon-2x.png';
    const shadowUrl = 'assets/leaflet/marker-shadow.png';

    L.Marker.prototype.options.icon = L.icon({
      iconRetinaUrl,
      iconUrl,
      shadowUrl,
      iconSize: [25, 41], // Default Leaflet icon size
      iconAnchor: [12, 41], // Anchor point of the icon
      popupAnchor: [1, -34], // Popup position
      shadowSize: [41, 41] // Default shadow size
    });

    L.Icon.Default.mergeOptions({
      iconRetinaUrl,
      iconUrl,
      shadowUrl
    });

    // Initialize the map
    this.map = L.map('map').setView([37.7749, -122.4194], 10); // Default location

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(this.map);

    // Add Sample delivery locations
    /*const locations = [
      { lat: 37.7749, lng: -122.4194, title: 'San Francisco' },
      { lat: 37.3382, lng: -121.8863, title: 'San Jose' },
      { lat: 37.8044, lng: -122.2711, title: 'Oakland' }
    ];*/

    this.locations.forEach(loc => {
      L.marker([loc.lat, loc.lng]).addTo(this.map).bindPopup(loc.title);
    });
  }

  ngOnInit(): void {
    this.searchService.searchText$.subscribe((searchText) => {
      this.dataSource.filter = searchText.trim().toLowerCase();
    });
    this.fetchShipments();
    this.fetchshipmentsTracking();
  }

  fetchshipmentsTracking(): void {
    this.http.get<any[]>('http://localhost:3000/shipmentsTracking').subscribe({
      next: (data) => {
        this.locations = data;
      },
      error: (err) => {
        console.error('Error fetching shipments:', err);
      }
    });
  }


  fetchShipments(): void {
    this.http.get<any[]>('http://localhost:3000/shipmentsList').subscribe({
      next: (data) => {
        this.dataSource.data = data;
        this.dataSource.paginator = this.paginator;
      },
      error: (err) => {
        console.error('Error fetching shipments:', err);
      }
    });
  }

  getStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'completed';
      case 'failed':
        return 'failed';
      case 'pending':
        return 'pending';
      case 'closed':
        return 'closed';
      default:
        return '';
    }
  }
}
