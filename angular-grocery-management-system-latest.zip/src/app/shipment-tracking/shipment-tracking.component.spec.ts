/*import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShipmentTrackingComponent } from './shipment-tracking.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ShipmentTrackingComponent', () => {
  let component: ShipmentTrackingComponent;
  let fixture: ComponentFixture<ShipmentTrackingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShipmentTrackingComponent, HttpClientTestingModule]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShipmentTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});*/
