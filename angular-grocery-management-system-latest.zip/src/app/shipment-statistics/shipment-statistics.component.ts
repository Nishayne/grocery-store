import { Component, OnInit, ViewChild, ElementRef, EventEmitter, Output, AfterViewInit, PLATFORM_ID, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { isPlatformBrowser } from '@angular/common';
import { Chart, ChartData, ChartOptions } from 'chart.js/auto';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-shipment-statistics',
  standalone: true,
  templateUrl: './shipment-statistics.component.html',
  styleUrls: ['./shipment-statistics.component.scss']
})
export class ShipmentStatisticsComponent implements OnInit/*, AfterViewInit*/ {
  @ViewChild('pieChart') pieChart!: ElementRef<HTMLCanvasElement>;
  apiUrl = 'http://localhost:3000/shipmentsList';
  shipmentData: any[] = [];
  chart!: Chart/* | null*/;
  isBrowser: boolean;

  @Output() viewAll = new EventEmitter<string>();

  emitViewAll() {
    this.viewAll.emit('Shipment Statistics');
  }

  constructor(private http: HttpClient, @Inject(PLATFORM_ID) private platformId: object, private searchService: SearchService) {
    this.isBrowser = isPlatformBrowser(this.platformId);
  }
  /*ngAfterViewInit(): void {
    if (this.isBrowser) {
      this.createChart();
    }
  }*/

  ngOnInit(): void {
    this.fetchShipmentStatistics();
  }

  fetchShipmentStatistics() {
    this.http.get<any[]>(this.apiUrl).subscribe({
      next: (data) => {
        this.shipmentData = data;
        this.createChart();
      },
      error: (err) => console.error('Failed to fetch shipment statistics', err)
    });
  }

  createChart() {
    /*const ctx = this.shipmentChartRef.nativeElement.getContext('2d');
    if (!ctx) return;*/

    const canvas = this.pieChart.nativeElement;

    // Ensure existing chart is destroyed before creating a new one
    if (this.pieChart) {
      this.pieChart.nativeElement.onclose;
    }

    /*const ctx = canvas.getContext('2d');
    if (!ctx) return;*/


    const completed = this.shipmentData.filter(s => s.status === 'completed').length;
    const inTransit = this.shipmentData.filter(s => s.status === 'in-transit').length;
    const failed = this.shipmentData.filter(s => s.status === 'failed').length;
    const pending = this.shipmentData.filter(s => s.status === 'pending').length;

    const chartData: ChartData<'doughnut'> = {
      labels: ['Completed', 'In-Transit', 'Failed', 'Pending'],
      datasets: [
        {
          data: [completed, inTransit, failed, pending],
          backgroundColor: ['#4CAF50', '#FFC107', '#F44336', '#FFEB3B'],
          hoverOffset: 4
        }
      ]
    };

    const chartOptions: ChartOptions<'doughnut'> = {
      responsive: true,
      //maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'right' // Or any other valid position
        },
        tooltip: {
          enabled: true,
          callbacks: {
            label: function (tooltipItem) {
              const value = tooltipItem.raw as number;
              const total = completed + inTransit + failed + pending;
              const percentage = ((value / total) * 100).toFixed(2);
              return `${tooltipItem.label}: ${value} (${percentage}%)`;
            }
          }
        }
      }
    };

    this.chart = new Chart(this.pieChart.nativeElement, {
      type: 'doughnut',
      data: chartData,
      options: chartOptions
    });
  }
}
