import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-pie-chart',
  standalone: true,
  imports: [],
  templateUrl: './pie-chart.component.html',
  styleUrl: './pie-chart.component.scss'
})
export class PieChartComponent {
  @Input() data:{
    online: number,
    offline: number,
    total:number
  }=
  {
    online:0,
    offline:0,
    total:0
  };
  get onlineAngle(){
    return(this.data.online /100)*360;
  }
  get offlineAngle(){
    return(this.data.offline/100)*360;
  }
}
