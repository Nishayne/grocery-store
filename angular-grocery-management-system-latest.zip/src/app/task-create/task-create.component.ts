import { CommonModule, DatePipe } from '@angular/common';
import { Component, Input, OnInit, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInput, MatInputModule } from '@angular/material/input';
import { MatSelect, MatSelectModule } from '@angular/material/select';
import { MatTabGroup, MatTab, MatTabsModule } from '@angular/material/tabs';
import { MatRadioModule } from '@angular/material/radio';
import { HttpClient } from '@angular/common/http';
import { TaskService } from '../task.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-task-create',
  standalone: true,
  imports: [CommonModule, MatFormFieldModule, MatSelectModule, ReactiveFormsModule, FormsModule, DatePipe, MatInput, MatInputModule,
    MatDatepickerModule, MatRadioModule,
    MatNativeDateModule, MatTabGroup, MatTabsModule],
  templateUrl: './task-create.component.html',
  styleUrl: './task-create.component.scss'
})

export class TaskCreateComponent implements OnInit {

  debugForm(): void {
    console.log("Form Status:", this.taskForm.status);
    console.log("Form Errors:", this.taskForm.errors);
    console.log("Form Value:", this.taskForm.value);
  }

  taskForm!: FormGroup;
  stockForm!: FormGroup;

  taskTypes: any[] = [];
  assignees: any[] = [];

  products: string[] = ['Cereals', 'Dairy', 'Beverages', 'Snacks', 'Frozen Foods'];
  statuses: string[] = ['Pending', 'Completed', 'In Progress'];

  priorities = ['Low', 'Medium', 'High'];
  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private taskService: TaskService
  ) {
  }
  ngOnInit(): void {

    // Form for Task Assignments Tab
    this.taskForm = this.fb.group({
      taskType: ['', Validators.required],
      assignee: ['', Validators.required],
      priority: ['Normal', Validators.required],
      dateTime: ['', Validators.required],
      location: ['', Validators.required],
    });

    // Form for Add New Stock Tab
    this.stockForm = this.fb.group({
      stockName: ['', Validators.required],
      stockCategory: ['', Validators.required],
      quantity: ['', [Validators.required, Validators.min(1)]],
      price: ['', [Validators.required, Validators.min(1)]],
      sellingPrice: ['', [Validators.required, Validators.min(1)]],
      supplier: ['', Validators.required],
      cashier: ['', Validators.required],
      status: ['', Validators.required],
      expiryDate: ['', Validators.required],
      entryDate: ['', Validators.required],
    });

    // Fetch task types and assignees from db.json
    this.getTaskTypes();
    this.getAssignees();
  }

  /*getTaskTypes() {
    this.taskService.getTaskTypes().subscribe({
      next: (data) => (this.taskTypes = data),
      error: (error) => console.error('Error fetching task types:', error)
    });
  }

  getAssignees() {
    this.taskService.getAssignees().subscribe({
      next: (data) => (this.assignees = data),
      error: (error) => console.error('Error fetching assignees:', error)
    });
  }*/

  // Better error handling with pipes due to returned empty object
  getTaskTypes() {
    this.taskService.getTaskTypes().pipe(
      catchError(error => {
        console.error('Error fetching task types:', error);
        return of([]); // Return an empty array or fallback data
      })
    ).subscribe(data => this.taskTypes = data);
  }

  // Better error handling with pipes due to returned empty object
  getAssignees() {
    this.taskService.getAssignees().pipe(
      catchError(error => {
        console.error('Error fetching assignees:', error);
        return of([]); // Return an empty array or fallback data
      })
    ).subscribe(data => this.assignees = data);
  }

  onCreateTask(): void {
    if (this.taskForm.valid) {
      this.taskService.createTask(this.taskForm.value).subscribe(response => {
        alert('Task Created: successfully');
      });
      console.log('Task Created:', this.taskForm.value);
    }
  }

  onAddStock(): void {
    if (this.stockForm.valid) {
      this.http.post<any>("http://localhost:3000/" + 'stockInventoryList', this.stockForm.value).subscribe(response => {
        alert('Stock Added: successfully');
      });
      console.log('Stock Added:', this.stockForm.value);
    }
  }
}
