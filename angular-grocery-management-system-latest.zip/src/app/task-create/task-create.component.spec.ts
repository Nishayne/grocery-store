import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TaskCreateComponent } from './task-create.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { of, throwError } from 'rxjs';
import { TaskService } from '../task.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // Import this


describe('TaskCreateComponent', () => {
  let component: TaskCreateComponent;
  let fixture: ComponentFixture<TaskCreateComponent>;
  let taskService: TaskService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, ReactiveFormsModule, TaskCreateComponent, BrowserAnimationsModule], //  Import required modules
      providers: [TaskService],
      declarations: []//TaskCreateComponent is standalone so cannot be declared, but should be imported
    }).compileComponents();

    fixture = TestBed.createComponent(TaskCreateComponent);
    component = fixture.componentInstance;
    taskService = TestBed.inject(TaskService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  /*it('should initialize the form1 with default values', () => {
    expect(component.taskForm.value).toEqual({
      title: '',
      description: '',
      dueDate: null,
      taskType: '',
      assignee: '',
      priority: 'Normal',
      dateTime: '',
      location: ''
    });
  });*/


  it('should initialize the form2 with default values', () => {
    expect(component.stockForm.value).toEqual({
      stockName: '',
      stockCategory: '',
      quantity: '',
      price: '',
      sellingPrice:'',
      supplier: '',
      cashier: '',
      status: '',
      expiryDate: '',
      entryDate: '',
    });
  });

  it('should validate required fields', () => {
    component.taskForm.controls['title'].setValue('');
    component.taskForm.controls['description'].setValue('');
    expect(component.taskForm.valid).toBeFalse(); // Form should be invalid
  });

  /*it('should submit the form successfully', () => {
    const mockTask = { title: 'New Task', description: 'Test Task', dueDate: new Date() };
    spyOn(taskService, 'createTask').and.returnValue(of(mockTask));

    component.taskForm.setValue(mockTask);
    component.createTask();

    expect(taskService.createTask).toHaveBeenCalledWith(mockTask);
  });

  it('should handle API errors on form submission', () => {
    spyOn(taskService, 'createTask').and.returnValue(throwError(() => new Error('Service Error')));

    component.createTask();

    expect(component.errorMessage).toBeTruthy(); // Error message should be set
  });*/
});
