import { TestBed, ComponentFixture } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LoginComponent } from './login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { AuthService } from '../auth.service';
import { Router } from 'express';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let mockAuthService: jasmine.SpyObj<AuthService>;
  //let mockRouter: jasmine.SpyObj<Router>;

  beforeEach(async () => {

    spyOn(localStorage, 'setItem').and.callFake((key: string, value: string) => {
      console.log(`Mock setItem: ${key} = ${value}`);
    });

    spyOn(localStorage, 'getItem').and.callFake((key: string) => {
      return key === 'token' ? 'mock-jwt-token' : null;
    });

    mockAuthService = jasmine.createSpyObj('AuthService', ['login']);
    /*mockAuthService.login.and.returnValue(of({ token: 'jwt-token' }));*/
    //mockAuthService.login.and.returnValue(of(void 0));
    mockAuthService.login('token232323');
    //mockRouter = jasmine.createSpyObj('Router',['route']);

    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule, //  Allows testing navigation
        FormsModule,
        ReactiveFormsModule,
        LoginComponent //  Import instead of declare
      ],
      declarations:[],//standalone cannot be in declarations -> LoginComponent
      providers: [{ provide: AuthService, useValue: mockAuthService },
        /*{ provide: Router, useValue: mockRouter }*/] //  Provide mock service
    }).compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should have a valid form when inputs are filled correctly', () => {
    component.loginForm.setValue({ username: 'user', password: 'user123' });
    expect(component.loginForm.valid).toBeTrue();
  });

  it('should call AuthService login on form submit', () => {
    component.loginForm.setValue({ username: 'user', password: 'user123' }); // Set form values

    component.onSubmit(); // Call form submit function

    expect(mockAuthService.login).toHaveBeenCalledWith('token232323'); // Check if login is called
  });

  /*it('should show error message for invalid form submission', () => {
    component.loginForm.setValue({ email: '', password: '' });
    component.onSubmit();
    expect(component.errorMessage).toBeTruthy();
  });*/

  it('should call AuthService login on form submit', () => {
    component.loginForm.setValue({ username: 'user', password: 'user123'  });

    //mockAuthService.login.and.returnValue(of({ token: 'jwt-token' })); //  Mock API response
    mockAuthService.login = jasmine.createSpy('login').and.returnValue(of(void 0));


    component.onSubmit();

    expect(mockAuthService.login).toHaveBeenCalledWith('token232323');
  });
});
