import { AfterViewInit, Component, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, OnInit, ViewChild } from '@angular/core';
import { CustomerService } from '../customer.service';
import { MatColumnDef, MatHeaderRowDef, MatRowDef, MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-customer-management',
  templateUrl: './customer-management.component.html',
  styleUrls: ['./customer-management.component.scss'],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  standalone: true,
  imports: [MatTableModule, MatPaginatorModule, MatSortModule, MatHeaderRowDef, MatRowDef,MatColumnDef,]
})
export class CustomerManagementComponent implements OnInit, AfterViewInit {
  dataSource = new MatTableDataSource<any>();
  //customers: any[] = [];

  constructor(private customerService: CustomerService, private searchService: SearchService) {}
  @ViewChild(MatSort) sort!: MatSort;  // Get MatSort reference

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;  // Attach sorting
  }

  ngOnInit(): void {
    this.fetchCustomers();
    this.searchService.searchText$.subscribe((searchText) => {
      this.dataSource.filter = searchText.trim().toLowerCase();
    });
  }

  fetchCustomers(): void {
    this.customerService.getCustomers().subscribe(data => {
      //this.customers = data;
      this.dataSource.data = data;
    });
  }
}
