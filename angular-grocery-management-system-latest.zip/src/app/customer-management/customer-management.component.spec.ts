import { CustomerService } from './../customer.service';
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CustomerManagementComponent } from './customer-management.component';

describe('CustomerManagementComponent', () => {
  let component: CustomerManagementComponent;
  let fixture: ComponentFixture<CustomerManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, CustomerManagementComponent], //  Ensure correct imports
      providers: [CustomerService] //  Provide the service
    }).compileComponents();

    fixture = TestBed.createComponent(CustomerManagementComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  /*it('should call loadCustomers on init', () => {
    spyOn(component, 'loadCustomers');
    component.ngOnInit();
    expect(component.loadCustomers).toHaveBeenCalled();
  });

  it('should display customer list', () => {
    component.customers = [
      { id: 1, name: 'John Doe', email: 'john@example.com' },
      { id: 2, name: 'Jane Smith', email: 'jane@example.com' }
    ];
    fixture.detectChanges();

    const compiled = fixture.nativeElement;
    expect(compiled.querySelectorAll('.customer-row').length).toBe(2);
  });

  it('should display "No customers found" if list is empty', () => {
    component.customers = [];
    fixture.detectChanges();

    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.no-customers').textContent).toContain('No customers found');
  });*/
});
