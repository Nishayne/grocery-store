import { TestBed, ComponentFixture } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HighDemandOrdersComponent } from './high-demand-orders.component';

describe('HighDemandOrdersComponent', () => {
  let component: HighDemandOrdersComponent;
  let fixture: ComponentFixture<HighDemandOrdersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, HighDemandOrdersComponent], //  Ensure correct imports
    }).compileComponents();

    fixture = TestBed.createComponent(HighDemandOrdersComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  /*it('should have a defined title', () => {
    expect(component.title).toBeDefined();
  });

  it('should load high demand orders on init', () => {
    spyOn(component, 'loadHighDemandOrders');
    component.ngOnInit();
    expect(component.loadHighDemandOrders).toHaveBeenCalled();
  });

  it('should render orders in the table', () => {
    component.highDemandOrders = [
      { id: 1, name: 'Product A', quantity: 100 },
      { id: 2, name: 'Product B', quantity: 150 }
    ];
    fixture.detectChanges();

    const compiled = fixture.nativeElement;
    expect(compiled.querySelectorAll('tr').length).toBeGreaterThan(1); // Includes header row
  });

  it('should show message when no orders found', () => {
    component.highDemandOrders = [];
    fixture.detectChanges();

    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.no-orders').textContent).toContain('No high-demand orders found');
  });*/
});
