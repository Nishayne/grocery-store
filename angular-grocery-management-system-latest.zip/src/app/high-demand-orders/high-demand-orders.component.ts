import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, ViewChild, OnInit } from '@angular/core';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatColumnDef, MatHeaderRowDef, MatRowDef, MatTable, MatTableDataSource, MatTableModule } from '@angular/material/table';
import { SearchService } from '../search.service';
import { HttpClient } from '@angular/common/http';

interface Order {
  id: number;
  product: string;
  quantity: number;
}

@Component({
  selector: 'app-high-demand-orders',
  templateUrl: './high-demand-orders.component.html',
  styleUrls: ['./high-demand-orders.component.scss'],
  standalone: true,
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  imports: [CommonModule, MatTableModule, MatPaginatorModule, MatSortModule, MatHeaderRowDef, MatRowDef, MatColumnDef,]
})
export class HighDemandOrdersComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = ['orderId', 'product', 'quantity'];
  //orders: MatTableDataSource<Order>;
  dataSource = new MatTableDataSource<any>();

  //totalOrders: number;

  constructor(private http: HttpClient, private searchService: SearchService) {
    /*const sampleOrders: Order[] = [
      { id: 1, product: 'Apples', quantity: 500 },
      { id: 2, product: 'Bananas', quantity: 450 },
      { id: 3, product: 'Oranges', quantity: 400 },
      { id: 4, product: 'Milk', quantity: 120 },
      { id: 5, product: 'Bread', quantity: 95 },
      { id: 6, product: 'Eggs', quantity: 150 }
    ];*/
    //this.orders = new MatTableDataSource(sampleOrders);
    /*this.dataSource.data = sampleOrders;
    this.totalOrders = sampleOrders.length;*/
  }

  ngOnInit(): void {
    this.fetchHighDemandOrders();
    this.searchService.searchText$.subscribe((searchText) => {
      this.dataSource.filter = searchText.trim().toLowerCase();
    });
  }

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  @ViewChild(MatSort) sort!: MatSort;  // Get MatSort reference

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;  // .Attach sorting
  }

  /*
    "stockInventoryOrdersChartData": [
    {
      "date": "2025-02-24T09:15:00Z",
      "numOfAvailableStock": 1,
      "numOfUnvailableStock": 35,
      "id": "a680"
    },
    */

  displayColumns: string[] = ['id', 'date', 'numOfAvailableStock', 'numOfUnvailableStock'];

  fetchHighDemandOrders(): void {
    this.http.get<any[]>('http://localhost:3000/stockInventoryOrdersChartData').subscribe({
      next: (data) => {
        this.dataSource.data = data;
        this.dataSource.paginator = this.paginator;
      },
      error: (err) => {
        console.error('Error fetching shipments:', err);
      }
    });
  }

}
