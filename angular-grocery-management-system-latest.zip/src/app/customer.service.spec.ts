import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CustomerService } from './customer.service';
import { HttpErrorResponse } from '@angular/common/http';

describe('CustomerService', () => {
  let service: CustomerService;
  let httpMock: HttpTestingController;
  let apiURL = "http://localhost:3000";

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [CustomerService]
    });

    service = TestBed.inject(CustomerService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify(); // Ensures that no unmatched requests remain
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should handle HTTP errors', () => {
    service.getCustomers().subscribe({
      next: () => fail('Expected error, but got a response'),
      error: (error) => {
        expect(error.status).toBe(404); // Expect a 404 error
      },
    });

    // Ensure the correct request is mocked
    const req = httpMock.expectOne(apiURL + '/assignees');
    expect(req.request.method).toBe('GET');

    // Respond with an error
    req.flush('Error', { status: 404, statusText: 'Not Found' });
  });

  it('should retrieve customers from API (GET)', () => {
    const mockCustomers = [
      { id: 1, name: 'John Doe', email: 'john@example.com' },
      { id: 2, name: 'Jane Doe', email: 'jane@example.com' }
    ];

    service.getCustomers().subscribe(customers => {
      expect(customers.length).toBe(2);
      expect(customers).toEqual(mockCustomers);
    });

    const req = httpMock.expectOne(apiURL+`/assignees`);
    expect(req.request.method).toBe('GET');
    req.flush(mockCustomers); // Respond with mock data
  });

  it('should add a new customer (POST)', () => {
    const newCustomer = { id: 3, name: 'Alice', email: 'alice@example.com' };

    service.addCustomer(newCustomer).subscribe(customer => {
      expect(customer).toEqual(newCustomer);
    });

    const req = httpMock.expectOne(apiURL+`/assignees`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(newCustomer);
    req.flush(newCustomer); // Respond with mock data
  });

  it('should handle HTTP errors', () => {
    const errorMsg = 'Failed to load customers';

    service.getCustomers().subscribe(
      () => fail('Expected an error'),
      (error: HttpErrorResponse) => {
        expect(error.status).toBe(500);
        expect(error.statusText).toBe('Internal Server Error');
      }
    );

    const req = httpMock.expectOne(apiURL + `/assignees`);
    req.flush(errorMsg, { status: 500, statusText: 'Internal Server Error' });
  });
});
