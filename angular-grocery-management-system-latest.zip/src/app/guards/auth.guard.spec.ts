import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { AuthService } from '../auth.service';

describe('AuthGuard', () => {
  let authGuard: AuthGuard;
  let authService: jasmine.SpyObj<AuthService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const authServiceSpy = jasmine.createSpyObj('AuthService', ['isAuthenticated']);
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    TestBed.configureTestingModule({
      providers: [
        AuthGuard,
        { provide: AuthService, useValue: authServiceSpy },
        { provide: Router, useValue: routerSpy }
      ]
    });

    authGuard = TestBed.inject(AuthGuard);
    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  it('should deny access for unexpected falsy return values', () => {
    authService.isAuthenticated.and.returnValue(null as any);
    expect(authGuard.canActivate()).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  
  it('should allow navigation if user is authenticated', () => {
    authService.isAuthenticated.and.returnValue(true);

    expect(authGuard.canActivate()).toBeTrue();
  });

  it('should deny navigation and redirect if user is not authenticated', () => {
    authService.isAuthenticated.and.returnValue(false);

    expect(authGuard.canActivate()).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('should allow navigation if user is authenticated', () => {
    authService.isAuthenticated.and.returnValue(true);
    expect(authGuard.canActivate()).toBeTrue();
    expect(router.navigate).not.toHaveBeenCalled(); // Ensure no redirection
  });

  it('should deny navigation and redirect if user is not authenticated', () => {
    authService.isAuthenticated.and.returnValue(false);
    expect(authGuard.canActivate()).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('should not call router.navigate when authentication succeeds', () => {
    authService.isAuthenticated.and.returnValue(true);
    authGuard.canActivate();
    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('should call router.navigate exactly once when authentication fails', () => {
    authService.isAuthenticated.and.returnValue(false);
    authGuard.canActivate();
    authGuard.canActivate();
    expect(router.navigate).toHaveBeenCalledTimes(2); // Once per failed call
  });

  it('should deny access for undefined/null authentication response', () => {
    authService.isAuthenticated.and.returnValue(undefined as any);
    expect(authGuard.canActivate()).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('should deny access for unexpected non-boolean return values', () => {
    authService.isAuthenticated.and.returnValue('invalid' as any);
    expect(authGuard.canActivate()).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('should work correctly if canActivate is called multiple times with different states', () => {
    authService.isAuthenticated.and.returnValue(true);
    expect(authGuard.canActivate()).toBeTrue();

    authService.isAuthenticated.and.returnValue(false);
    expect(authGuard.canActivate()).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });
});
