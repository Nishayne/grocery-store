import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ReportService } from './report.service';

describe('ReportService', () => {
  let service: ReportService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ReportService]
    });

    service = TestBed.inject(ReportService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify(); // Ensure no outstanding requests
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch reports successfully', () => {
    const mockReports = [
      { id: 1, title: 'Sales Report', data: [100, 200, 300] },
      { id: 2, title: 'Stock Report', data: [50, 75, 100] }
    ];

    service.getReports().subscribe((reports) => {
      expect(reports.length).toBe(2);
      expect(reports).toEqual(mockReports);
    });

    const req = httpMock.expectOne('http://localhost:3000/reports');
    expect(req.request.method).toBe('GET');
    req.flush(mockReports);
  });

  it('should return an empty array when no reports are found', () => {
    service.getReports().subscribe((reports) => {
      //expect(reports.length).toBe(0);
      expect(reports).toEqual([]);
    });

    const req = httpMock.expectOne('http://localhost:3000/reports');
    expect(req.request.method).toBe('GET');
    req.flush([]);
  });

  it('should handle API errors gracefully', () => {
    service.getReports().subscribe(
      () => fail('Expected an error, but got a response'),
      (error) => {
        expect(error).toBeTruthy();
      }
    );

    const req = httpMock.expectOne('http://localhost:3000/reports');
    expect(req.request.method).toBe('GET');
    req.flush('Something went wrong', { status: 500, statusText: 'Server Error' });
  });

  /*it('should post a new report successfully', () => {
    const newReport = { id: 3, title: 'New Report', data: [10, 20, 30] };

    service.createReport(newReport).subscribe((report) => {
      expect(report).toEqual(newReport);
    });

    const req = httpMock.expectOne('http://localhost:3000/reports');
    expect(req.request.method).toBe('POST');
    req.flush(newReport);
  });

  it('should delete a report successfully', () => {
    const reportId = 1;

    service.deleteReport(reportId).subscribe((response) => {
      expect(response).toBeNull();
    });

    const req = httpMock.expectOne(`http://localhost:3000/reports/${reportId}`);
    expect(req.request.method).toBe('DELETE');
    req.flush(null);
  });*/
});
