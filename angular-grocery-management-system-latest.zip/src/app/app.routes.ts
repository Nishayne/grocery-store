import { RouterModule, Routes } from '@angular/router';
import { provideRouter } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './signup/signup.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ShipmentTrackingComponent } from './shipment-tracking/shipment-tracking.component';
import { BlogListingComponent } from './blog-listing/blog-listing.component';
import { NgModel } from '@angular/forms';
import { Component, NgModule } from '@angular/core';
import { LayoutComponent } from './layout/layout.component';
import { StocksManagementComponent } from './stocks-management/stocks-management.component';
import { ReportsAnalyticsComponent } from './reports-analytics/reports-analytics.component';
import { CustomerManagementComponent } from './customer-management/customer-management.component';
import { HighDemandOrdersComponent } from './high-demand-orders/high-demand-orders.component';
import { TaskCreateComponent } from './task-create/task-create.component';

import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [] = [
    {path:'', component: LoginComponent},
    {path: 'login', component: LoginComponent},
    {path:'sign-up', component: SignUpComponent},
    {
        path:'',
        component:LayoutComponent,
        children:[
            {path:'dashboard',component:DashboardComponent,canActivate: [AuthGuard] },
            {path:'stock',component:StocksManagementComponent, canActivate: [AuthGuard] },
            {path:'ship',component:ShipmentTrackingComponent,canActivate: [AuthGuard] },
            {path: 'reporting', component: ReportsAnalyticsComponent,canActivate: [AuthGuard]  },
            {path: 'customers', component: CustomerManagementComponent,canActivate: [AuthGuard]  },
            {path:'blogs',component:BlogListingComponent,canActivate: [AuthGuard] },
            {path: 'high-demand-orders', component: HighDemandOrdersComponent,canActivate: [AuthGuard]  },
            {path: 'create-task', component: TaskCreateComponent,canActivate: [AuthGuard]  },
            //{path: '**', redirectTo: '/dashboard',canActivate: [AuthGuard]  } // Default fallback
        ]
    }
];

NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export const AppRoutes=provideRouter(routes);
