import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HTTP_INTERCEPTORS, HttpClient, HttpRequest } from '@angular/common/http';
import { AuthInterceptor } from './auth-interceptor.service';

describe('AuthInterceptorService', () => {
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule], //  Ensure HttpClientTestingModule is used
      providers: [
        { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
      ]
    });

    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  afterEach(() => {
    httpMock.verify(); // Ensure no open requests
  });

  it('should add Authorization header to outgoing requests', () => {
    const mockToken = 'mock-jwt-token';

    //  Mock localStorage.getItem to return a token
    spyOn(localStorage, 'getItem').and.returnValue(mockToken);

    httpClient.get('/api/test').subscribe();

    const req = httpMock.expectOne('/api/test');

    //  Assert Authorization header is present
    expect(req.request.headers.has('Authorization')).toBeTrue();
    expect(req.request.headers.get('Authorization')).toBe(`Bearer ${mockToken}`);

    req.flush({});
  });

  it('should work with multiple interceptors', () => {
    TestBed.resetTestingModule(); //  Reset module before reconfiguring

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
      ]
    });

    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);

    const mockToken = 'mock-jwt-token';
    spyOn(localStorage, 'getItem').and.returnValue(mockToken);

    httpClient.get('/api/test-multiple').subscribe();

    const req = httpMock.expectOne('/api/test-multiple');

    //  Ensure Authorization header exists even with multiple interceptors
    expect(req.request.headers.has('Authorization')).toBeTrue();
    expect(req.request.headers.get('Authorization')).toBe(`Bearer ${mockToken}`);

    req.flush({});
  });
});
