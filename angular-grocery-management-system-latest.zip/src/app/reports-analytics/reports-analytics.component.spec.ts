import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReportsAnalyticsComponent } from './reports-analytics.component';
import { of, throwError } from 'rxjs';
import { ReportService } from '../report.service';

describe('ReportsAnalyticsComponent', () => {
  let component: ReportsAnalyticsComponent;
  let fixture: ComponentFixture<ReportsAnalyticsComponent>;
  let reportService: ReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule], //  Mock HTTP requests
      providers: [ReportService]
    }).compileComponents();

    fixture = TestBed.createComponent(ReportsAnalyticsComponent);
    component = fixture.componentInstance;
    reportService = TestBed.inject(ReportService);
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

/*  it('should fetch reports on init', () => {
    const mockReports = [
      { id: 1, title: 'Sales Report', data: [100, 200, 300] },
      { id: 2, title: 'Stock Report', data: [50, 75, 100] }
    ];

    spyOn(reportService, 'getReports').and.returnValue(of(mockReports));

    component.ngOnInit();
    fixture.detectChanges();

    expect(reportService.getReports).toHaveBeenCalled();
    expect(component.reports.length).toBe(2);
    expect(component.reports).toEqual(mockReports);
  });*/

  /*it('should handle empty reports', () => {
    spyOn(reportService, 'getReports').and.returnValue(of([]));

    component.ngOnInit();
    fixture.detectChanges();

    expect(reportService.getReports).toHaveBeenCalled();
    expect(component.reports.length).toBe(0);
  });*/

  /*it('should handle service errors gracefully', () => {
    spyOn(reportService, 'getReports').and.returnValue(throwError(() => new Error('Service failed')));

    component.ngOnInit();
    fixture.detectChanges();

    expect(reportService.getReports).toHaveBeenCalled();
    expect(component.reports.length).toBe(0); // No reports should be set
    expect(component.error).toBeTruthy(); // Error flag should be set
  });*/
});
