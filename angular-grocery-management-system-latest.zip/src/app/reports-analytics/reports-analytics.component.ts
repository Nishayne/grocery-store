import { Component, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, OnInit } from '@angular/core';
import { ReportService } from '../report.service';
import { MatColumnDef, MatHeaderRowDef, MatRowDef, MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';

@Component({
  selector: 'app-reports-analytics',
  templateUrl: './reports-analytics.component.html',
  styleUrls: ['./reports-analytics.component.scss'],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  standalone: true,
  imports: [MatTableModule, MatPaginatorModule, MatSortModule, MatHeaderRowDef, MatRowDef,MatColumnDef,]
})
export class ReportsAnalyticsComponent implements OnInit {
  dataSource = new MatTableDataSource<any>();
  //reportData: any[] = [];

  constructor(private reportService: ReportService) {}

  ngOnInit(): void {
    this.fetchReports();
  }

  fetchReports(): void {
      this.dataSource.data = ["Stocks","Shipments"];
  }
}
