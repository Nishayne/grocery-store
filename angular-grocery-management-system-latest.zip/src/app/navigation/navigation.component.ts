import { Component } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatIcon } from '@angular/material/icon';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-navigation',
  standalone: true,
  imports:[NgFor,NgIf, RouterModule, MatIcon],
  templateUrl: './navigation.component.html',
  styleUrl: './navigation.component.scss',
  providers:[HeaderComponent]
})
export class NavigationComponent {
  constructor(private header: HeaderComponent) {}
  menuItems = [
    { icon: 'dashboard', label: 'Dashboard', route:'/dashboard' },
    { icon: 'inventory', label: 'Stocks Management', route:'/stock' },
    { icon: 'local_shipping', label: 'Shipment Tracking', route:'/ship' },
    { icon: 'trending_up', label: 'High Demand Orders', route: '/high-demand-orders' },
    { icon: 'playlist_add', label: 'Create Task', route: '/create-task' },
    { icon: 'bar_chart', label: 'Reports & Analytics',route:'/reporting' },
    { icon: 'groups', label: 'Customer Management', route:'/customers' },
    { icon: 'article', label: 'Food Safety Blogs', route:'/blogs' },
    { icon: 'settings', label: 'Settings', route:'/settings' },
    { icon: 'person', label: 'My Account', route:'/account' },
    { icon: 'help', label: 'Help & Support', route:'/help' },
  ];
  isExpanded = false;

  toggleMenu(expand: boolean) {
    this.isExpanded = expand;
  }

  logout() {
    this.header.logout();
  }
}
