import { Component } from '@angular/core';
import { NavigationComponent } from "../navigation/navigation.component";
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { SidebarService } from '../sidebar.service';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [NavigationComponent, RouterOutlet, HeaderComponent],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss'
})
export class LayoutComponent {

  isSidebarOpen = true;

  constructor(private sidebarService: SidebarService) {}

  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
    this.sidebarService.toggleSidebar(this.isSidebarOpen); // Notify chart to resize
  }
}
