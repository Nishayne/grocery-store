import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private apiUrl = 'http://localhost:3000/';

  constructor(private http: HttpClient) {
  }
  getTaskTypes(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl + 'taskTypes');
  }

  getAssignees(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl + 'assignees');
  }

  createTask(task: any): Observable<any> {
    return this.http.post<any>(this.apiUrl + 'tasks', task);
  }
}
