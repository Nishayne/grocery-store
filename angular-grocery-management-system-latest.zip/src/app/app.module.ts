import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// Import Angular Material Modules
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatColumnDef, MatHeaderRowDef, MatRowDef, MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatIconModule } from '@angular/material/icon';

import { AppComponent } from './app.component';

import { StocksManagementComponent } from './stocks-management/stocks-management.component';
import { CustomerManagementComponent } from './customer-management/customer-management.component';
import { ReportsAnalyticsComponent } from './reports-analytics/reports-analytics.component';
import { HighDemandOrdersComponent } from './high-demand-orders/high-demand-orders.component';
import { TaskCreateComponent } from './task-create/task-create.component';
import { HeaderComponent } from './header/header.component';
import { RouterModule } from '@angular/router';
import { routes } from './app.routes';
import { SignUpComponent } from './signup/signup.component';

import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './auth-interceptor.service';

@NgModule({

  declarations: [],

  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],

  imports: [
    RouterModule.forRoot(routes),
    BrowserModule,  BrowserAnimationsModule,
    FormsModule,
    CommonModule,
    MatSortModule,
    MatTableModule, MatPaginatorModule, MatFormFieldModule,
    MatInputModule,MatSelectModule,MatDatepickerModule,MatNativeDateModule,
    MatIconModule, MatButtonModule,
    MatHeaderRowDef, MatRowDef,MatColumnDef,
    ReactiveFormsModule, FormsModule,
    StocksManagementComponent, CustomerManagementComponent, ReportsAnalyticsComponent,
  ],
  providers: [
    AppComponent, HeaderComponent,
    provideHttpClient(withFetch()),
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true}
  ],
  bootstrap: []
})
export class AppModule { }
