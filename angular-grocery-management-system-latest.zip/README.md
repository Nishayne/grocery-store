![ScreenShot](./Screenshot.png)


## All code generated from 
* ng new app ...
* ng generate component ,,,
* ng generate service ...
* ng generate module ...
* ng generate guard guards/auth

## above automatically generate test cases

# for leaflet (map)
* npm install leaflet --save
* npm install @types/leaflet --save-dev
*#update angular.json with leaflet style
 *   "styles": [
 *     "@angular/material/prebuilt-themes/indigo-pink.css",
 *     "node_modules/leaflet/dist/leaflet.css",
* cd src/assets/
* mkdir leaflet
* cd leaflet/
* cp ../../../node_modules/leaflet/dist/images/marker-icon.png ../../assets/leaflet/
* cp ../../../node_modules/leaflet/dist/images/marker-icon-2x.png ../../assets/leaflet/
* cp ../../../node_modules/leaflet/dist/images/marker-shadow.png ../../assets/leaflet/

# to run the json server
* npm install json-server --save-dev
* json-server --watch db.json --port 3000

## to install 
* cd to the project folder after ng new app ...
* npm install # ng cache clean && npm cache clean --force && rm -Rf node_modules
* ng serve

browse to http://localhost:4200

## to test run 
  ng test

#### Note: For testing on linux
export CHROME_BIN=$(which chromium)
npm run test

## to run docker just run 

docker build . 

within the corresponding folders command prompt

clean old images created by docker using
docker system prune -y

to see if image is build and ready to use
docker ps -a

## Ensure budget memory is corect in angular.json else you can get production build failure and that is docker build fails

# GroceryStoreManagementSystem

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 17.3.8.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
